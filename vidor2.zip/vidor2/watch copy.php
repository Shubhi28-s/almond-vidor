<?php
include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
  section{
      width:500px;
      margin:auto;
  }
        
iframe{
            /* display: flex;
            align-items: center;
            justify-content: center; */
            /* position: absolute; */
            top: 30px;
            /* left: 50px; */
            width: 550px;
            height: 500px;
            margin: 0 auto !important;
            text-align:center;

        }

        </style>
</head>
<body>
    <?php
    if(isset($_GET['id']))
    {
        $id= $_GET['id'];
        $sql = "SELECT url FROM `videovalues` WHERE id ='$id'";
        $res= mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($res);
$name=$row['url'];
        ?>
        <section id="watch.php" class="mx-auto text-center"
        >
    
<iframe src="./uploads/<?php echo $name?>"  allowfullscreen></iframe>
</section>
        <!-- <video width="415" height="300">
            <source src= "uploads/<?$row['url']?>"type="video/mp4">
        </video> -->
        <?php
    } 
    ?>

     
</body>
</html>