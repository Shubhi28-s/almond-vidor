<?php
include("db.php");
$sql="select * from `videovalues`";
$res=mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($res)){
    $id=$row['id'];
    $name=$row['url'];
    echo"<h4> <a href='videos.php?id=$id'>$name</a></h4>";
}
?>