<?php
include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
  section{
      width:500px;
      margin:auto;
  }
        
iframe{
            /* display: flex;
            align-items: center;
            justify-content: center; */
            /* position: absolute; */
            top: 30px;
            /* left: 50px; */
            width: 550px;
            height: 500px;
            margin: 0 auto !important;
            text-align:center;

        }

        </style>
</head>
<body>
    <?php
    if(isset($_GET['id']))
    {
        $id= $_GET['id'];
        $sql = "SELECT * FROM `videovalues` WHERE id ='$id'";
        $res= mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($res);

$name=$row['url'];
echo($name);
$video=$row['video_id'];
$value=$row['values'];
echo($value);
$key=$row['keys'];
$starttime=$row['start_time'];
echo($starttime);
$endtime=$row['end_time'];
$desktop=$row['desktop_view'];
$mobile=$row['mobile_view'];
$screen=$row['fullScreen_view'];
        ?>
        <section id="watch.php" class="mx-auto text-center"
        >
    
<iframe src="videos.php?id=<?php echo $id;?>"  allowfullscreen></iframe>
</section>
        <!-- <video width="415" height="300">
            <source src= "uploads/<?$row['url']?>"type="video/mp4">
        </video> -->
        <?php
    } 
    ?>

     
</body>
</html>