<?php
$servername = 
'localhost';
$username= "root";
$password= "";
$dbname = "vingage";

$conn = mysqli_connect($servername,$username,$password,$dbname);
 
if($conn){
//   echo "connection ok!";
}
else {
    //echo "connection failed!";
    //for knowing the reason why connection has failed,
    //we use die() function in php

    die("connection failed because".mysqli_connect_error());
}

?>