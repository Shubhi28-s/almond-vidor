<?php
include("db.php");
    if(isset($_GET['id']))
    {
        $id= $_GET['id'];

        $vsql = "SELECT * FROM `my_videos` WHERE id ='$id'";
        $vres= mysqli_query($conn,$vsql);
        $vrow = mysqli_fetch_assoc($vres);
        $vid = $vrow['id'];
        $vurl = $vrow['url'];
        
        $sql = "SELECT * FROM `videovalues1` WHERE `video_id` = '$vid' ";
        $res= mysqli_query($conn,$sql);
        $row = $res->fetch_all(MYSQLI_ASSOC);

        //  print_r($row); die();
       
$name=  $vurl;
// echo($name);
// $video=$row['video_id'];
// $value=$row['values'];
// // echo($value);
// $key=$row['keys'];
// $starttime=$row['start_time'];
// // echo($starttime);
// $endtime=$row['end_time'];
// $desktop=$row['desktop_view'];
// $mobile=$row['mobile_view'];
// $screen=$row['fullScreen_view'];
    } 
?>
     


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
  <title>Video</title>
  <link href="https://fonts.googleapis.com/css?family=Acme|Archivo+Narrow|Barlow|Bebas+Neue|Bree+Serif|Bungee+Inline|Catamaran|Crete+Round|Courgette|Dancing+Script|Exo+2|Graduate|Inconsolata|Indie+Flower|Kanit|Kreon|Lato|Libre+Franklin|Lobster|Martel|Merienda|Overpass|PT+Sans+Narrow|Playball|Patrick+Hand|Roboto|Sacramento|Source+Sans+Pro|Sriracha|Unna&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="main.css">
  <style>
    body {
      font-family: ZurichBTBold !important;
      font-weight: 200;

    }
  </style>
</head>

<body>

  <div class='player-container'>
   
    <video class="video" id="video" preload="metadata" disableremoteplayback="" webkit-playsinline="" playsinline="" poster=""  poster="https://vmediadata.s3.ap-south-1.amazonaws.com/acadian/videos/vdo-3SRuQ1599145779570660001.png" autoplay="">
      <source src="../vingaje/public/VIDEO/<?php echo $name?>" type="video/mp4">
    </video>

    <div class='play-btn-big'></div>
    <div class='controls'>
      <div class="time"><span class="time-current"></span><span class="time-total"></span></div>
      <div class='progress'>
        <div class='progress-filled'></div>
      </div>
      <div class='controls-main'>
        <div class='controls-left'>
          <div class='volume'>
            <div class='volume-btn loud'>
              <svg width="26" height="24" viewBox="0 0 26 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6.75497 17.6928H2C0.89543 17.6928 0 16.7973 0 15.6928V8.30611C0 7.20152 0.895431 6.30611 2 6.30611H6.75504L13.9555 0.237289C14.6058 -0.310807 15.6 0.151473 15.6 1.00191V22.997C15.6 23.8475 14.6058 24.3098 13.9555 23.7617L6.75497 17.6928Z" transform="translate(0 0.000518799)" fill="white" />
                <path id="volume-low" d="M0 9.87787C2.87188 9.87787 5.2 7.66663 5.2 4.93893C5.2 2.21124 2.87188 0 0 0V2C1.86563 2 3.2 3.41162 3.2 4.93893C3.2 6.46625 1.86563 7.87787 0 7.87787V9.87787Z" transform="translate(17.3333 7.44955)" fill="white" />

                <path id="volume-high" d="M0 16.4631C4.78647 16.4631 8.66667 12.7777 8.66667 8.23157C8.66667 3.68539 4.78647 0 0 0V2C3.78022 2 6.66667 4.88577 6.66667 8.23157C6.66667 11.5773 3.78022 14.4631 0 14.4631V16.4631Z" transform="translate(17.3333 4.15689)" fill="white" />
                <path id="volume-off" d="M1.22565 0L0 1.16412L3.06413 4.0744L0 6.98471L1.22565 8.14883L4.28978 5.23853L7.35391 8.14883L8.57956 6.98471L5.51544 4.0744L8.57956 1.16412L7.35391 0L4.28978 2.91031L1.22565 0Z" transform="translate(17.3769 8.31403)" fill="white" />
              </svg>

            </div>
            <div class='volume-slider'>
              <div class='volume-filled'></div>
            </div>
          </div>
        </div>
        <div class='play-btn paused'></div>
        <div class="controls-right">

          <div class='fullscreen'>
            <svg width="30" height="22" viewBox="0 0 30 22" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 0V-1.5H-1.5V0H0ZM0 18H-1.5V19.5H0V18ZM26 18V19.5H27.5V18H26ZM26 0H27.5V-1.5H26V0ZM1.5 6.54545V0H-1.5V6.54545H1.5ZM0 1.5H10.1111V-1.5H0V1.5ZM-1.5 11.4545V18H1.5V11.4545H-1.5ZM0 19.5H10.1111V16.5H0V19.5ZM24.5 11.4545V18H27.5V11.4545H24.5ZM26 16.5H15.8889V19.5H26V16.5ZM27.5 6.54545V0H24.5V6.54545H27.5ZM26 -1.5H15.8889V1.5H26V-1.5Z" transform="translate(2 2)" fill="white" />
            </svg>

            </svg>

          </div>
        </div>
      </div>
    </div>

    <div id="main"></div>


    <script>
      //ELEMENT SELECTORS
      var player = document.querySelector('.player-container');
      var video = document.querySelector('#video');
      var playBtn = document.querySelector('.play-btn');
      var volumeBtn = document.querySelector('.volume-btn');
      var volumeSlider = document.querySelector('.volume-slider');
      var volumeFill = document.querySelector('.volume-filled');
      var progressSlider = document.querySelector('.progress');
      var progressFill = document.querySelector('.progress-filled');
      var textCurrent = document.querySelector('.time-current');
      var textTotal = document.querySelector('.time-total');
      var speedBtns = document.querySelectorAll('.speed-item');
      var fullscreenBtn = document.querySelector('.fullscreen');

      //GLOBAL VARS
      let lastVolume = 1;
      let isMouseDown = false;

      //PLAYER FUNCTIONS
      function togglePlay() {
        if (video.paused) {
          video.play();
        } else {
          video.pause();
        }
        playBtn.classList.toggle('paused');
      }
      function togglePlayBtn() {
        playBtn.classList.toggle('playing');
      }

      function toggleMute() {
        if (video.volume) {
          lastVolume = video.volume;
          video.volume = 0;
          volumeBtn.classList.add('muted');
          volumeFill.style.width = 0;
        } else {
          video.volume = lastVolume;
          volumeBtn.classList.remove('muted');
          volumeFill.style.width = `${lastVolume * 100}%`;
        }
      }
      function changeVolume(e) {
        volumeBtn.classList.remove('muted');
        let volume = e.offsetX / volumeSlider.offsetWidth;
        volume < 0.1 ? volume = 0 : volume = volume;
        volumeFill.style.width = `${volume * 100}%`;
        video.volume = volume;
        if (volume > 0.7) {
          volumeBtn.classList.add('loud');
        } else if (volume < 0.7 && volume > 0) {
          volumeBtn.classList.remove('loud');
        } else if (volume == 0) {
          volumeBtn.classList.add('muted');
        }
        lastVolume = volume;
      }
      function neatTime(time) {
        // var hours = Math.floor((time % 86400)/3600)
        var minutes = Math.floor((time % 3600) / 60);
        var seconds = Math.floor(time % 60);
        seconds = seconds > 9 ? seconds : `0${seconds}`;
        return `${minutes}:${seconds}`;
      }
      function updateProgress(e) {
        progressFill.style.width = `${video.currentTime / video.duration * 100}%`;
        textCurrent.innerHTML = `${neatTime(video.currentTime)} / ${neatTime(video.duration)}`;
      }
      function setProgress(e) {
        const newTime = e.offsetX / progressSlider.offsetWidth;
        // progressFill.style.width = `${newTime * 100}%`;
        // video.currentTime = newTime * video.duration;
      }
      function launchIntoFullscreen(element) {
        if (element.requestFullscreen) {
          element.requestFullscreen();
        } else if (element.mozRequestFullScreen) {
          element.mozRequestFullScreen();
        } else if (element.webkitRequestFullscreen) {
          element.webkitRequestFullscreen();
        } else if (element.msRequestFullscreen) {
          element.msRequestFullscreen();
        }
      }
      function exitFullscreen() {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.mozCancelFullScreen) {
          document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
        }
      }
      var fullscreen = false;
      function toggleFullscreen() {
        fullscreen ? exitFullscreen() : launchIntoFullscreen(player)
        fullscreen = !fullscreen;
      }
      function setSpeed(e) {
        console.log(parseFloat(this.dataset.speed));
        video.playbackRate = this.dataset.speed;
        speedBtns.forEach(speedBtn => speedBtn.classList.remove('active'));
        this.classList.add('active');
      }
      function handleKeypress(e) {
        switch (e.key) {
          case " ":
            togglePlay();
          case "ArrowRight":
            video.currentTime += 5;
          case "ArrowLeft":
            video.currentTime -= 5;
          default:
            return;
        }
      }
      //EVENT LISTENERS
      playBtn.addEventListener('click', togglePlay);
      video.addEventListener('click', togglePlay);
      video.addEventListener('play', togglePlayBtn);
      video.addEventListener('pause', togglePlayBtn);
      video.addEventListener('ended', togglePlayBtn);
      video.addEventListener('timeupdate', updateProgress);
      video.addEventListener('canplay', updateProgress);
      volumeBtn.addEventListener('click', toggleMute);
      window.addEventListener('mousedown', () => isMouseDown = true)
      window.addEventListener('mouseup', () => isMouseDown = false)
      // volumeSlider.addEventListener('mouseover', changeVolume);
      volumeSlider.addEventListener('click', changeVolume);
      progressSlider.addEventListener('click', setProgress);
      fullscreenBtn.addEventListener('click', toggleFullscreen);
      speedBtns.forEach(speedBtn => {
        speedBtn.addEventListener('click', setSpeed);
      })
      window.addEventListener('keydown', handleKeypress);

// controller end

// js start from shubhi 


    </script>


   

    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script>
      
        //Perform Ajax request.
      
            // var text = JSON.stringify(data);
            // console.log("text", text);

            // var vid = document.getElementById("video");

            // for (i = 0; i < data.length; i++) {

            //   $('#main').append('<div class="label1" id="main_' + data[i].id + '" style="display: none">' + data[i]['values'] + '</div>');

            function videoPlayNames(data) {
              
                // data = [{
                //     "id": 1,
                //     "video_id": 1,
                //     "values": "Jatin",
                //     "keys": "senderName",
                //     "start_time": 35,
                //     "end_time": 39,
                //     "desktop_view": " position: absolute; top: 40.5%; left: 23%; width: 58vw; height: 9vw; text-align: left;width:73vw; user-select: none; padding:1vw; color:rgb(255, 255, 255); font-family: Lobster; font-size:4vw; letter-spacing: 0.2vw;",
                //     "mobile_view": " position: absolute; top: 46.5%; left: 25%; width: 58vw; height: 9vw; text-align: left; width:73vw; user-select: none; padding:1vw; color:rgb(145, 205, 125); font-family: Lobster; font-size:5.5vw; letter-spacing: 0.2vw;",
                //     "fullScreen_view": " position: absolute; top: 46.5%; left: 30%; width: 58vw; height: 9vw; text-align: left;  width:73vw; user-select: none; padding:1vw; color:#fff; font-family: Lobster; font-size:3vw; letter-spacing: 0.2vw;",
                //     "video_name": "",
                //     "url": "",
                //     "duration": "0",
                //     "status": 0,
                //     "created_at": "2021-09-08T10:10:48.000Z",
                //     "updated_at": "2021-09-08T10:10:48.000Z"
                // },
                // {
                //     "id": 2,
                //     "video_id": 1,
                //     "values": "Bhupesh",
                //     "keys": "senderName",
                //     "start_time": 35,
                //     "end_time": 39,
                //     "desktop_view": " position: absolute; top: 40.5%; left: 23%; width: 58vw; height: 9vw; text-align: left;width:73vw; user-select: none; padding:1vw; color:rgb(255, 255, 255); font-family: Lobster; font-size:4vw; letter-spacing: 0.2vw;",
                //     "mobile_view": " position: absolute; top: 46.5%; left: 25%; width: 58vw; height: 9vw; text-align: left; width:73vw; user-select: none; padding:1vw; color:rgb(145, 205, 125); font-family: Lobster; font-size:5.5vw; letter-spacing: 0.2vw;",
                //     "fullScreen_view": " position: absolute; top: 46.5%; left: 30%; width: 58vw; height: 9vw; text-align: left;  width:73vw; user-select: none; padding:1vw; color:#fff; font-family: Lobster; font-size:3vw; letter-spacing: 0.2vw;",
                //     "video_name": "",
                //     "url": "",
                //     "duration": "0",
                //     "status": 0,
                //     "created_at": "2021-09-08T10:10:48.000Z",
                //     "updated_at": "2021-09-08T10:10:48.000Z"
                // }];
               
            // var text = JSON.stringify(data);
            // // console.log("text", text);

            // var vid = document.getElementById("video");

            // for (i = 0; i < data.length; i++) {

            //   $('#main').append('<div class="label1" id="main_' + data[i].id + '" style="display: none">' + data[i]['values'] + '</div>');



       
            console.log("Data:: ", data);
            var text = JSON.stringify(data);
            
            var vid = document.getElementById("video");

            for (i = 0; i < data.length; i++) {

               let left =data[i]['left'];
               let right =data[i]['right'];
               let top =data[i]['top'];
               let bottom=data[i]['bottom'];
               let fontfamily=data[i]['fontFamily'];
               let fontsize=data[i]['font_size'];
               let color=data[i]['colors'];

               let effect=data[i]['effect'];
               
              console.log(color);

              $('#main').append('<div class="label1" id="main_' + data[i].id + '" style="'+'display: none; position:absolute;width:72vw; left:'+ left +'; right:'+ right +'; top:'+ top +';bottom:'+ bottom +';font-family:'+ fontfamily +';font-size:'+ fontsize +';color:'+ color +';" >' + data[i]['values'] + '</div>');

            }


            vid.ontimeupdate = function() {
              cTime = parseInt(vid.currentTime);
              console.log("cTime :: ", cTime);

              for (i = 0; i < data.length; i++) {
                console.log("Data :: ", );
                start_time1 = data[i].start_time;
                end_time1 = data[i].end_time;
                if (cTime >= start_time1 && cTime < end_time1) {
                  console.log("Show Video");
                  document.getElementById("main_" + data[i].id).style.display = "block"
                  document.getElementById("main_" + data[i].id).setAttribute("style",data[i]+'left:' +left );
                } else {
                  document.getElementById("main_" + data[i].id).style.display = "none"
                }
              }




            }

      
         
    

            // vid.ontimeupdate = function() {
            //   cTime = parseInt(vid.currentTime);
            //   console.log("cTime :: ", cTime);

            //   for (i = 0; i < data.length; i++) {
            //     console.log("Data :: ", );
            //     start_time1 = data[i].start_time;
            //     end_time1 = data[i].end_time;
            //     if (cTime >= start_time1 && cTime < end_time1) {
            //       console.log("Show Video");
            //       document.getElementById("main_" + data[i].id).style.display = "block"
            //       document.getElementById("main_" + data[i].id).setAttribute("style", data[i].id);
            //     } else {
            //       document.getElementById("main_" + data[i].id).style.display = "none"
            //     }
            //   }



            // };

        }

            videoPlayNames(<?=json_encode($row)?>);
       




            var Video = document.getElementById("video");

var supposedCurrentTime = 0;
Video.addEventListener('timeupdate', function() {
  if (!Video.seeking) {
    supposedCurrentTime = Video.currentTime;
  }
});

Video.addEventListener('seeking', function() {

  var delta = Video.currentTime - supposedCurrentTime;
  if (Math.abs(delta) > 0.01) {
    console.log("Seeking is disabled");
    Video.currentTime = supposedCurrentTime;
  }
});



    
    </script>




</body>

</html>