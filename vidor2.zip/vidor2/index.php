<?php
include("db.php");
if (isset($_POST['upload']))
{
    $name = $_FILES['url']['name'];
    $tmp = $_FILES['url']['tmp_name'];
    move_uploaded_file($tmp,"uploads/".$name);
    $sql="Insert into `videovalues` (url) Values('$name')";
    $res = mysqli_query($conn,$sql);
    // if($res==1){
    //     echo"<h3> video inserted successfully</h3>";
    // }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="index.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="url">
    <input type="Submit" name="upload" value="Upload!">
</form>
<?php
if (isset($_post['upload']))
{
    echo"<br />".$name." has been inserted successfully";
    
}
?>
</body>
</html>